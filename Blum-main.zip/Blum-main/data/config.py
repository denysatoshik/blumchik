# api id, hash
API_ID = 11111111
API_HASH = 'Your api hash'

USE_TG_BOT = False # True if you want use tg, else False
BOT_TOKEN = '283993:kdmioieiweikiokeocki4okew' # API TOKEN get in @BotFather
CHAT_ID = '22803822' # Your telegram id

# задержка между подключениями к аккаунтам
ACC_DELAY = [5, 15]

# тип прокси
PROXY_TYPE = "socks5" # http/socks5

# папка с сессиями (не менять)
WORKDIR = "sessions/"

# использование прокси
USE_PROXY = True # True/False

# путь к node.js (можно узнать такими командами)
# which node  - linux
# where node - windows
NODE_PATH = 'node'

# скок поинтов с игры
POINTS = [100, 140] #[min, max]

# играть дроп гейм
DROP_GAME = True # True/False

# делать таски
DO_TASKS = True

# сон между играми
SLEEP_GAME_TIME = [30,50] #[min,max]

# мини задержки
MINI_SLEEP = [3,7] #[min,max]

# доп задержка после 8часов 
SLEEP_8HOURS = [60*60,120*60] #[min,max] seconds

hello ='''              _                               __  _        
 _ __    ___ | |_  _   _   __ _  ___   ___   / _|| |_  ___ 
| '_ \  / _ \| __|| | | | / _` |/ __| / _ \ | |_ | __|/ __|
| |_) ||  __/| |_ | |_| || (_| |\__ \| (_) ||  _|| |_ \__ \\
| .__/  \___| \__| \__, | \__,_||___/ \___/ |_|   \__||___/
|_|                |___/        

'''
